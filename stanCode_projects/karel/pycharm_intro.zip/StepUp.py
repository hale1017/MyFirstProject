"""
Name: Jerry
File: StepUp.py
---------------------
Pre-condition: Karel was at (1, 1), beeper was at (1, 2)
Post-condition: Karel is at (2, 5), 99 beepers are at (2, 4)
"""
from karel.stanfordkarel import *


def main():
    pass











































####### DO NOT EDIT CODE BELOW THIS LINE ########

if __name__ == '__main__':
    execute_karel_task(main)
